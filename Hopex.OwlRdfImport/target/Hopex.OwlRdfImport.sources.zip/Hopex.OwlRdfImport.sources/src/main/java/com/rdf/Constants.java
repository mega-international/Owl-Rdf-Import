package com.rdf;

public class Constants {
  public static final String MAE_MAE_METACLASS = "~j0000000C420[MetaClass]";
  public static final String MA_SHORTNAME      = "~Z20000000D60[Short Name]";
  public static final String MA_RDFID          = "~CFmhlMxNT1iE[External Identifier]";
  public static final String MA_HEXAIDABS      = "~H20000000550[_HexaIdAbs]";
  public static final String DELIMITER         = "({[::]})";
}
