package com.rdf;

public class MappingCondition {
  public String field;
  public String value;
}
